# FFmpeg Android Audio Builder with MP3

Android向けに、音声用途へ絞ったFFmpeg共有ライブラリをABI別に生成します。
LAME 3.100を先にPIC静的ライブラリとしてビルドし、FFmpegの`libavcodec.so`へリンクします。
そのため、実行時に別の`libmp3lame.so`を同梱する必要はありません。

## 対応出力Encoder

- ALAC
- FLAC
- AAC
- MP3 via `libmp3lame`
- PCM s16/s24/s32/float

## 対応環境

- Linux x86_64
- WSL2 Linux
- macOS
- Android NDK r26以降を推奨
- Python 3.11以降
- GNU Make
- pkg-config

Ubuntu／WSL:

```bash
sudo apt update
sudo apt install -y python3 make pkg-config xz-utils
export ANDROID_NDK_ROOT="$HOME/Android/Sdk/ndk/28.2.13676358"
```

## ビルド

```bash
./build.sh --clean
```

デフォルトABI:

```text
arm64-v8a
armeabi-v7a
```

x86_64を含める場合:

```bash
./build.sh --clean --abis arm64-v8a armeabi-v7a x86_64
```

既存ソースを使い、ネットワーク取得を行わない場合:

```bash
./build.sh \
  --clean \
  --source /path/to/ffmpeg-7.1.5 \
  --lame-source /path/to/lame-3.100 \
  --no-download
```


## カバーアート変換

DSRE-Mobile互換のメタデータ処理向けに、`libswscale`、MJPEG Encoder、MJPEG/PNG/WebP/BMP Decoderを有効化します。PNG Decoder用にAndroid NDKのzlibへリンクします。JPEG以外の埋め込み画像は、アプリ側JNIでMJPEGへ変換してALAC/M4A、FLAC、MP3へ添付できます。

## 出力

```text
ffmpeg-android-audio-mp3-7.1.5.zip
output/
├── include/
├── jniLibs/
│   ├── arm64-v8a/
│   └── armeabi-v7a/
├── build-info/
├── build-manifest.json
├── INTEGRATION.md
└── NOTICE.md
```

各ABIの`jniLibs`には次が入ります。

```text
libavutil.so
libswresample.so
libswscale.so
libavcodec.so
libavformat.so
```

`libmp3lame.a`は`libavcodec.so`へ静的リンクされます。ビルド確認用として`build-info/<ABI>/`にも保存されますが、APKへ入れる必要はありません。

## 検証

ビルド処理は、現行FFmpegの`config_components.h`を最優先で確認し、`config.h`および`ffbuild/config.mak`にもフォールバックして`libmp3lame` Encoderの有効化を検査します。FFmpeg 9.xではCodecごとの設定が`config_components.h`へ分離されているためです。見つからない場合は成功扱いにしません。
`build-manifest.json`にはFFmpeg／LAMEバージョン、ABI、SHA-256、MP3 Encoder情報を記録します。

## LAMEソース検証

既定のLAME 3.100アーカイブはSHA-256を検証します。

```text
ddfe36cab873794038ae2c1210557ad34857a4b6bdc515785d1da9e175b1da1e
```

別バージョンを使用する場合は、対応するハッシュを指定してください。

```bash
./build.sh \
  --lame-version 3.100 \
  --lame-sha256 <SHA-256>
```
