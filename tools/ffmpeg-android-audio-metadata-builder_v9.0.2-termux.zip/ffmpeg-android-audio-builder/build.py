#!/usr/bin/env python3
"""Reproducible FFmpeg + libmp3lame audio builder for Android.

Builds LAME 3.100 as a PIC static library per ABI, then links it into shared
FFmpeg libraries. Output supports ALAC, FLAC, AAC, MP3, PCM and cover-art conversion without an
additional libmp3lame.so runtime dependency.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import urllib.request
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
DEFAULT_FFMPEG_VERSION = "9.0.2"
DEFAULT_LAME_VERSION = "3.100"
DEFAULT_LAME_SHA256 = "ddfe36cab873794038ae2c1210557ad34857a4b6bdc515785d1da9e175b1da1e"
DEFAULT_API = 23
ABI_CONFIG = {
    "arm64-v8a": {"arch": "aarch64", "cpu": "armv8-a", "clang": "aarch64-linux-android", "host": "aarch64-linux-android", "extra": []},
    "armeabi-v7a": {"arch": "arm", "cpu": "armv7-a", "clang": "armv7a-linux-androideabi", "host": "arm-linux-androideabi", "extra": ["--enable-thumb"]},
    "x86_64": {"arch": "x86_64", "cpu": "x86-64", "clang": "x86_64-linux-android", "host": "x86_64-linux-android", "extra": ["--disable-asm"]},
}
ENCODERS = ["alac", "flac", "aac", "libmp3lame", "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_f32le", "mjpeg"]
DECODERS = ["alac", "flac", "aac", "mp3", "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_f32le", "vorbis", "opus", "mjpeg", "png", "webp", "bmp"]
DEMUXERS = ["mov", "flac", "wav", "mp3", "ogg", "matroska", "aac"]
MUXERS = ["ipod", "mov", "flac", "wav", "adts", "mp3"]
PARSERS = ["aac", "flac", "mpegaudio", "opus", "vorbis"]
PROTOCOLS = ["file", "pipe"]
LIBS = ["libavutil", "libswresample", "libswscale", "libavcodec", "libavformat"]


def run(cmd: list[str], cwd: Path | None = None, env: dict[str, str] | None = None) -> None:
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), cwd=cwd, env=env, check=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""): h.update(block)
    return h.hexdigest()


def running_in_termux() -> bool:
    prefix = os.getenv("PREFIX", "")
    return bool(os.getenv("TERMUX_VERSION")) or "com.termux" in prefix or Path("/data/data/com.termux/files/usr").is_dir()


def host_tag_candidates() -> list[str]:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == "darwin":
        return ["darwin-x86_64"]
    if system != "linux":
        raise RuntimeError("Run this builder on Linux, macOS, WSL2, or Termux.")
    if machine in {"aarch64", "arm64"}:
        # Community/native NDK layouts use one of these tags. Official Google Linux
        # NDK archives currently use linux-x86_64 host binaries and cannot execute
        # natively in an aarch64 Termux process.
        return ["linux-aarch64", "linux-arm64", "linux-x86_64"]
    if machine in {"x86_64", "amd64"}:
        return ["linux-x86_64", "linux-aarch64", "linux-arm64"]
    return [f"linux-{machine}", "linux-x86_64", "linux-aarch64", "linux-arm64"]


def ndk_root(cli: str | None) -> Path:
    raw = cli or os.getenv("ANDROID_NDK_ROOT") or os.getenv("ANDROID_NDK_HOME")
    if not raw:
        sdk = os.getenv("ANDROID_SDK_ROOT") or os.getenv("ANDROID_HOME")
        if sdk:
            ndks = Path(sdk) / "ndk"
            candidates = sorted((p for p in ndks.iterdir() if p.is_dir()), reverse=True) if ndks.is_dir() else []
            if candidates: return candidates[0].resolve()
        raise RuntimeError("Set ANDROID_NDK_ROOT or pass --ndk /path/to/android-ndk.")
    p = Path(raw).expanduser().resolve()
    if not p.is_dir(): raise RuntimeError(f"Android NDK directory not found: {p}")
    return p


def download(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file(): return
    print(f"Downloading {url}")
    partial = destination.with_suffix(destination.suffix + ".part")
    try:
        with urllib.request.urlopen(url) as response, partial.open("wb") as out:
            shutil.copyfileobj(response, out)
        partial.replace(destination)
    finally:
        partial.unlink(missing_ok=True)


def safe_extract(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:*") as tf:
        tf.extractall(destination, filter="data")


def ffmpeg_source(args: argparse.Namespace) -> Path:
    if args.source:
        p = Path(args.source).expanduser().resolve()
        if not (p / "configure").is_file(): raise RuntimeError(f"FFmpeg configure not found in {p}")
        return p
    if args.no_download: raise RuntimeError("--no-download requires both --source and --lame-source")
    base = PROJECT / ".sources"
    dest = base / f"ffmpeg-{args.ffmpeg_version}"
    if not (dest / "configure").is_file():
        archive = base / f"ffmpeg-{args.ffmpeg_version}.tar.xz"
        download(f"https://ffmpeg.org/releases/ffmpeg-{args.ffmpeg_version}.tar.xz", archive)
        safe_extract(archive, base)
    if not (dest / "configure").is_file(): raise RuntimeError("FFmpeg source extraction failed")
    return dest


def lame_source(args: argparse.Namespace) -> Path:
    if args.lame_source:
        p = Path(args.lame_source).expanduser().resolve()
        if not (p / "configure").is_file(): raise RuntimeError(f"LAME configure not found in {p}")
        return p
    if args.no_download: raise RuntimeError("--no-download requires both --source and --lame-source")
    base = PROJECT / ".sources"
    dest = base / f"lame-{args.lame_version}"
    if not (dest / "configure").is_file():
        archive = base / f"lame-{args.lame_version}.tar.gz"
        download(f"https://downloads.sourceforge.net/project/lame/lame/{args.lame_version}/lame-{args.lame_version}.tar.gz", archive)
        actual = sha256(archive)
        if args.lame_sha256 and actual.lower() != args.lame_sha256.lower():
            archive.unlink(missing_ok=True)
            raise RuntimeError(f"LAME SHA-256 mismatch: expected {args.lame_sha256}, got {actual}")
        safe_extract(archive, base)
    if not (dest / "configure").is_file(): raise RuntimeError("LAME source extraction failed")
    return dest


def is_executable(path: Path) -> bool:
    return path.is_file() and os.access(path, os.X_OK)


def toolchain(ndk: Path, override: str | None = None) -> Path:
    if override:
        explicit = Path(override).expanduser().resolve()
        if not (explicit / "bin").is_dir() or not (explicit / "sysroot").is_dir():
            raise RuntimeError(f"Invalid NDK LLVM toolchain: {explicit}")
        return explicit
    root = ndk / "toolchains/llvm/prebuilt"
    for tag in host_tag_candidates():
        candidate = root / tag
        if (candidate / "bin").is_dir() and (candidate / "sysroot").is_dir():
            clang = candidate / "bin/clang"
            # Do not select an x86_64-only toolchain on native Termux ARM64 merely
            # because the directory exists.
            if running_in_termux() and platform.machine().lower() in {"aarch64", "arm64"} and tag == "linux-x86_64":
                continue
            if is_executable(clang):
                return candidate
    found = ", ".join(p.name for p in root.iterdir() if p.is_dir()) if root.is_dir() else "none"
    expected = ", ".join(host_tag_candidates())
    suffix = " On Termux/ARM64 install a native aarch64 NDK toolchain or pass --toolchain PATH." if running_in_termux() else ""
    raise RuntimeError(f"Runnable NDK LLVM toolchain not found under {root}. Expected: {expected}; found: {found}.{suffix}")


def tools(ndk: Path, abi: str, api: int, toolchain_override: str | None = None) -> dict[str, Path]:
    cfg = ABI_CONFIG[abi]; selected = toolchain(ndk, toolchain_override); bin_dir = selected / "bin"
    values = {
        "cc": bin_dir / f"{cfg['clang']}{api}-clang",
        "cxx": bin_dir / f"{cfg['clang']}{api}-clang++",
        "ar": bin_dir / "llvm-ar", "nm": bin_dir / "llvm-nm",
        "ranlib": bin_dir / "llvm-ranlib", "strip": bin_dir / "llvm-strip",
        "sysroot": selected / "sysroot",
    }
    for name, path in values.items():
        if name != "sysroot" and not path.is_file(): raise RuntimeError(f"NDK tool missing: {path}")
    return values


def build_lame(source: Path, ndk: Path, abi: str, api: int, jobs: int, clean: bool, toolchain_override: str | None = None) -> Path:
    cfg = ABI_CONFIG[abi]; tc = tools(ndk, abi, api, toolchain_override)
    build = PROJECT / "build" / "lame" / abi
    prefix = PROJECT / "install" / "lame" / abi
    if clean:
        shutil.rmtree(build, ignore_errors=True); shutil.rmtree(prefix, ignore_errors=True)
    library = prefix / "lib" / "libmp3lame.a"
    if library.is_file() and not clean: return prefix
    build.mkdir(parents=True, exist_ok=True); prefix.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update({
        "CC": str(tc["cc"]), "CXX": str(tc["cxx"]), "AR": str(tc["ar"]),
        "RANLIB": str(tc["ranlib"]), "STRIP": str(tc["strip"]),
        "CFLAGS": "-O3 -fPIC -ffunction-sections -fdata-sections",
        "CPPFLAGS": f"--sysroot={tc['sysroot']}",
        "LDFLAGS": "-Wl,--gc-sections -Wl,-z,max-page-size=16384",
    })
    run([
        source / "configure", f"--prefix={prefix}", f"--host={cfg['host']}",
        "--disable-shared", "--enable-static", "--disable-frontend", "--with-pic",
    ], cwd=build, env=env)
    run(["make", f"-j{jobs}"], cwd=build, env=env)
    run(["make", "install"], cwd=build, env=env)
    if not library.is_file() or not (prefix / "include/lame/lame.h").is_file():
        raise RuntimeError(f"LAME build did not produce expected files for {abi}")
    return prefix


def ffmpeg_configure(source: Path, prefix: Path, lame: Path, ndk: Path, abi: str, api: int, toolchain_override: str | None = None) -> tuple[list[str], dict[str, str]]:
    cfg = ABI_CONFIG[abi]; tc = tools(ndk, abi, api, toolchain_override)
    pkg_config = shutil.which("pkg-config")
    if not pkg_config: raise RuntimeError("pkg-config is required. Install the pkg-config package.")
    env = os.environ.copy()
    env["PKG_CONFIG_LIBDIR"] = str(lame / "lib/pkgconfig")
    env["PKG_CONFIG_PATH"] = str(lame / "lib/pkgconfig")
    args = [
        str(source / "configure"), f"--prefix={prefix}", "--target-os=android",
        f"--arch={cfg['arch']}", f"--cpu={cfg['cpu']}", "--enable-cross-compile",
        f"--sysroot={tc['sysroot']}", f"--cc={tc['cc']}", f"--cxx={tc['cxx']}",
        f"--ar={tc['ar']}", f"--nm={tc['nm']}", f"--ranlib={tc['ranlib']}", f"--strip={tc['strip']}",
        f"--pkg-config={pkg_config}", "--pkg-config-flags=--static",
        "--enable-shared", "--disable-static", "--disable-programs", "--disable-doc",
        "--disable-debug", "--disable-network", "--disable-autodetect", "--disable-everything",
        "--enable-avcodec", "--enable-avformat", "--enable-avutil", "--enable-swresample", "--enable-swscale",
        "--enable-libmp3lame", "--enable-zlib", "--enable-small", "--disable-symver",
        f"--extra-cflags=-O3 -fPIC -ffunction-sections -fdata-sections -I{lame / 'include'}",
        f"--extra-ldflags=-Wl,--gc-sections -Wl,-z,max-page-size=16384 -L{lame / 'lib'}",
        "--extra-libs=-lmp3lame -lz -lm",
    ]
    args += [f"--enable-encoder={x}" for x in ENCODERS]
    args += [f"--enable-decoder={x}" for x in DECODERS]
    args += [f"--enable-demuxer={x}" for x in DEMUXERS]
    args += [f"--enable-muxer={x}" for x in MUXERS]
    args += [f"--enable-parser={x}" for x in PARSERS]
    args += [f"--enable-protocol={x}" for x in PROTOCOLS]
    args += cfg["extra"]
    return args, env


def build_ffmpeg(source: Path, lame: Path, ndk: Path, abi: str, api: int, jobs: int, clean: bool, toolchain_override: str | None = None) -> dict:
    build = PROJECT / "build" / "ffmpeg" / abi
    prefix = PROJECT / "install" / "ffmpeg" / abi
    if clean:
        shutil.rmtree(build, ignore_errors=True); shutil.rmtree(prefix, ignore_errors=True)
    build.mkdir(parents=True, exist_ok=True); prefix.mkdir(parents=True, exist_ok=True)
    cmd, env = ffmpeg_configure(source, prefix, lame, ndk, abi, api, toolchain_override)
    run(cmd, cwd=build, env=env); run(["make", f"-j{jobs}"], cwd=build, env=env); run(["make", "install"], cwd=build, env=env)
    libs = {}
    for name in LIBS:
        plain = prefix / "lib" / f"{name}.so"
        candidates = sorted((prefix / "lib").glob(f"{name}.so*"), key=lambda p: (p.name.count('.'), len(p.name)))
        selected = plain if plain.is_file() else next((p for p in candidates if p.is_file()), None)
        if selected is None: raise RuntimeError(f"Missing {name} for {abi}")
        libs[name] = selected
    config_h = build / "config.h"
    config_components_h = build / "config_components.h"
    config_mak = build / "ffbuild" / "config.mak"
    macro = "CONFIG_LIBMP3LAME_ENCODER 1"
    component_enabled = config_components_h.is_file() and macro in config_components_h.read_text(errors="ignore")
    legacy_enabled = config_h.is_file() and macro in config_h.read_text(errors="ignore")
    make_enabled = config_mak.is_file() and "CONFIG_LIBMP3LAME_ENCODER=yes" in config_mak.read_text(errors="ignore")
    if not (component_enabled or legacy_enabled or make_enabled):
        searched = ", ".join(str(path) for path in (config_components_h, config_h, config_mak))
        raise RuntimeError(
            f"FFmpeg libmp3lame encoder was not enabled for {abi}. Checked: {searched}"
        )
    return {
        "abi": abi, "prefix": prefix, "lame": lame, "libs": libs,
        "config": config_h, "config_components": config_components_h,
        "config_mak": config_mak,
    }


def package(results: list[dict], ffmpeg_version: str, lame_version: str, api: int) -> Path:
    out = PROJECT / "output"; shutil.rmtree(out, ignore_errors=True)
    jni = out / "jniLibs"; include = out / "include"; build_info = out / "build-info"
    manifests = []
    for result in results:
        abi_dir = jni / result["abi"]; abi_dir.mkdir(parents=True, exist_ok=True)
        entries = []
        for name, src in result["libs"].items():
            dst = abi_dir / f"{name}.so"; shutil.copy2(src, dst)
            entries.append({"file": dst.name, "sha256": sha256(dst), "bytes": dst.stat().st_size})
        info_dir = build_info / result["abi"]; info_dir.mkdir(parents=True, exist_ok=True)
        if result["config"].is_file():
            shutil.copy2(result["config"], info_dir / "ffmpeg-config.h")
        if result["config_components"].is_file():
            shutil.copy2(result["config_components"], info_dir / "ffmpeg-config-components.h")
        if result["config_mak"].is_file():
            shutil.copy2(result["config_mak"], info_dir / "ffmpeg-config.mak")
        shutil.copy2(result["lame"] / "lib/libmp3lame.a", info_dir / "libmp3lame.a")
        manifests.append({"abi": result["abi"], "libraries": entries, "mp3Encoder": "libmp3lame (statically linked into libavcodec.so)"})
    shutil.copytree(results[0]["prefix"] / "include", include)
    manifest = {
        "ffmpegVersion": ffmpeg_version, "lameVersion": lame_version, "minSdk": api,
        "licenseProfile": "LGPL-oriented; no GPL/nonfree options. LAME is LGPL and statically linked into shared libavcodec.so.",
        "enabledOutputEncoders": ["alac", "flac", "aac", "libmp3lame", "pcm", "mjpeg"],
        "enabledCoverDecoders": ["mjpeg", "png", "webp", "bmp"],
        "coverConversion": "libswscale + MJPEG encoder",
        "abis": manifests,
    }
    (out / "build-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    for name in ("NOTICE.md", "INTEGRATION.md"): shutil.copy2(PROJECT / name, out / name)
    archive = PROJECT / f"ffmpeg-android-audio-mp3-{ffmpeg_version}.zip"
    shutil.make_archive(str(archive.with_suffix("")), "zip", out)
    return archive


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ndk")
    ap.add_argument("--toolchain", help="Explicit NDK LLVM prebuilt directory containing bin/ and sysroot/ (useful on Termux ARM64)")
    ap.add_argument("--source", help="Existing FFmpeg source directory")
    ap.add_argument("--lame-source", help="Existing LAME source directory")
    ap.add_argument("--ffmpeg-version", default=DEFAULT_FFMPEG_VERSION)
    ap.add_argument("--lame-version", default=DEFAULT_LAME_VERSION)
    ap.add_argument("--lame-sha256", default=DEFAULT_LAME_SHA256)
    ap.add_argument("--api", type=int, default=DEFAULT_API)
    ap.add_argument("--abis", nargs="+", default=["arm64-v8a", "armeabi-v7a"], choices=ABI_CONFIG)
    ap.add_argument("--jobs", type=int, default=max(1, os.cpu_count() or 1))
    ap.add_argument("--clean", action="store_true"); ap.add_argument("--no-download", action="store_true")
    ap.add_argument("--configure-only", action="store_true")
    args = ap.parse_args()
    if args.api < 21: ap.error("API level below 21 is not supported")
    ndk = ndk_root(args.ndk); ffmpeg = ffmpeg_source(args); lame = lame_source(args)
    selected_toolchain = toolchain(ndk, args.toolchain)
    termux_text = "yes" if running_in_termux() else "no"
    print(f"FFmpeg: {ffmpeg}\nLAME: {lame}\nNDK: {ndk}\nToolchain: {selected_toolchain}\nTermux: {termux_text}\nABIs: {', '.join(args.abis)}\nAPI: {args.api}")
    results = []
    for abi in args.abis:
        lame_prefix = build_lame(lame, ndk, abi, args.api, args.jobs, args.clean, str(selected_toolchain))
        if args.configure_only:
            cmd, _ = ffmpeg_configure(ffmpeg, PROJECT / "install/ffmpeg" / abi, lame_prefix, ndk, abi, args.api, str(selected_toolchain))
            print("\n".join(cmd)); continue
        results.append(build_ffmpeg(ffmpeg, lame_prefix, ndk, abi, args.api, args.jobs, args.clean, str(selected_toolchain)))
    if args.configure_only: return 0
    archive = package(results, args.ffmpeg_version, args.lame_version, args.api)
    print(f"Completed: {archive}")
    return 0

if __name__ == "__main__":
    try: raise SystemExit(main())
    except (RuntimeError, subprocess.CalledProcessError, urllib.error.URLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr); raise SystemExit(1)
