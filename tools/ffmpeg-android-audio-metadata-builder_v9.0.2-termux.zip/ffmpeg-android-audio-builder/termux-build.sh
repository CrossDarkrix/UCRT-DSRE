#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
: "${ANDROID_SDK_ROOT:=${ANDROID_HOME:-$HOME/android-sdk}}"
export ANDROID_SDK_ROOT

if [[ "$(uname -m)" != "aarch64" && "$(uname -m)" != "arm64" ]]; then
  echo "ERROR: This Termux launcher supports an ARM64 host." >&2
  exit 1
fi

NDK_ROOT="${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}"
if [[ -z "$NDK_ROOT" && -d "$ANDROID_SDK_ROOT/ndk" ]]; then
  NDK_ROOT="$(find "$ANDROID_SDK_ROOT/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
fi
if [[ -z "$NDK_ROOT" || ! -d "$NDK_ROOT" ]]; then
  echo "ERROR: Set ANDROID_NDK_ROOT to the Android NDK directory." >&2
  exit 1
fi

TOOLCHAIN="${ANDROID_NDK_TOOLCHAIN:-}"
if [[ -z "$TOOLCHAIN" ]]; then
  for tag in linux-aarch64 linux-arm64; do
    candidate="$NDK_ROOT/toolchains/llvm/prebuilt/$tag"
    if [[ -x "$candidate/bin/clang" && -d "$candidate/sysroot" ]]; then
      TOOLCHAIN="$candidate"
      break
    fi
  done
fi
if [[ -z "$TOOLCHAIN" ]]; then
  cat >&2 <<MSG
ERROR: No native ARM64 NDK toolchain was found.
The Google SDK Manager NDK normally contains linux-x86_64 host binaries, which
cannot run directly in native ARM64 Termux. Install a Termux/aarch64 NDK and set:
  export ANDROID_NDK_ROOT=/path/to/android-ndk
  export ANDROID_NDK_TOOLCHAIN=/path/to/android-ndk/toolchains/llvm/prebuilt/linux-aarch64
MSG
  exit 1
fi

exec python3 "$SCRIPT_DIR/build.py" --ndk "$NDK_ROOT" --toolchain "$TOOLCHAIN" "$@"
