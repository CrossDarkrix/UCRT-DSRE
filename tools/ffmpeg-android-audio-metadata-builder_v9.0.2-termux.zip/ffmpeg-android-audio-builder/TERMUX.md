# Termux ARM64 support

The builder supports native ARM64 Termux hosts through an aarch64-host NDK LLVM toolchain. It auto-detects `linux-aarch64` and `linux-arm64`, or accepts an exact toolchain with `--toolchain`. The dedicated `termux-build.sh` launcher discovers the newest SDK NDK root, validates the ARM64 host, selects a native toolchain, and forwards all build arguments.

Google's official Linux NDK download exposes `linux-x86_64` host tools. Those files target Android outputs but the compiler process itself is an x86_64 Linux host binary, so native ARM64 Termux cannot execute it directly. A Termux/aarch64 NDK, an ARM64 Linux NDK toolchain, or an explicit emulation/proot arrangement is required. This project intentionally does not silently run x86_64 host tools under emulation.
